# Guardian Intelligence — voice

One line: **Confident without ceremony.**

## Six attributes

1. **Plural.** First-person plural. Never "I." Never "our company." Just "we."
2. **Present.** Present tense. We describe what we do now.
3. **Measured.** No hype, no scarcity. The work is the argument.
4. **Grounded.** A specific noun or number in every paragraph.
5. **Unpatronizing.** We trust the reader.
6. **Unhurried.** White space is load-bearing. No exclamation marks. One em-dash per paragraph, maximum.

## Banned words

`empower`, `unlock`, `reimagine`, `seamless`, `cutting-edge`, `game-changing`, `industry-leading`, `next-generation`, `democratize`, `disrupt`, `leverage` (as a verb), `journey`, `passionate`, `operator` (use **founder** in user-facing copy; `operator` survives in internal variable names and architecture docs).

## Banned grammar

No BuzzFeed hooks. No setup-and-reveal.

- "It's not just X, it's Y."
- "That's not an X, that's a Y."
- "It's more than X, it's Y."
- Any variant of the same rug-pull.

We say the thing.

## Invariants alongside voice

- **Argent only.** The mark is always Argent. On non-Iron grounds the mark carries its own dark ground (iron chip on Paper, circular emboss on Flare).
- **Audience split.** Iron for customers. Flare for the world. Paper for editorial.
- **Wings belong to Guardian.** Product marques (Metal, Console) inherit the house and set their own name in Geist. Products do not get wings.
- **One loud word per page.** The page can have one Flare-colored word. Not two. Not zero if the page is earning a loud moment.
- **One italic line per page.** Fraunces italic is reserved for the mission line.

## Tone anchors

When you are unsure, read a paragraph from one of these:

- Berkshire Hathaway shareholder letters
- The Economist leader column
- Muji product descriptions
- 37signals, *How We Work*

If the paragraph reads like a VC deck, a LinkedIn post, or a keynote hook, it fails.
