# Guardian Intelligence — brand kit

Contents:

- `argent-iron.svg` — Argent wings on Iron (customer-facing surfaces).
- `argent-flare-emboss.svg` — Argent wings in a circular ink emboss on Flare (broadcast surfaces).
- `argent-paper-chip.svg` — Argent wings in an iron chip on Paper (editorial surfaces).
- `voice.md` — Guardian Intelligence voice guide.

The full brand system, specimens, and rules live at https://anveio.com/design. On first reference, write "Guardian Intelligence." On subsequent reference, "Guardian." The company is an American applied intelligence firm based in Seattle.

Questions: press@guardianintelligence.org
